window._env_ = {
  BASE_URL: "http://localhost:8080/cadastro_boot/api",
}
